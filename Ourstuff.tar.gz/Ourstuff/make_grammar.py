import subprocess

f = open("readfrom.txt","r")
lines = f.readlines()
f.close()

num = 0
text = "#JSGF V1.0;grammar hello;"

for line in lines:
    text = text + "<" + str(num) + "> = "
    for word in line:
        if word == "=":
            text = text + ";"
            break
        else:
            text = text + word
    num = num + 1

text = text + "public <command> = "
for x in range(0, num):
    if x == (num - 1):
        text = text + "<%d>;"%x
        f = open("grammar.jsgf","w")
        f.write(text)
        f.close()
    else:
        text = text + "<%d> | "%x

args = ('sphinx_jsgf2fsg', "-jsgf", "grammar.jsgf", "-fsg", "grammar.fsg")
subprocess.Popen(args, stdout=subprocess.PIPE)

with open("grammar.word", "w") as outfile:
	subprocess.Popen(["perl", "fsg2wlist.pl", "grammar.fsg"], stdout=outfile)

subprocess.Popen(["python", "get_dict.py"])
