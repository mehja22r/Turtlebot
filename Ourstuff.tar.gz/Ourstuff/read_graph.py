import networkx as nx

#G = nx.read_graphml("/home/raeesa/networkx/examples/more_dialogue_graph.graphml", unicode)
G = nx.read_graphml("/home/raeesa/networkx/examples/write_graphml.graphml",unicode)
#G = nx.read_graphml("/home/raeesa/Desktop/write_graphml.graphml",unicode)
root = 'n1'
current = root

f = open("words.log","r+")
f.seek(0)
f.truncate()

with open("clean.log", "w"):
    pass

while True:
    line = f.readline()

    if line:
        #with open("clean.log","a") as g:
            if line[0][:1] in '0123456789':
                # 9 numbers, colon, space
		#g.seek(0)
                speech = line[11:].rstrip()
	        #g.close()
		print speech
		for e in G.edges(current, data=True):
			if str(speech) == str(e[2].values()[0]):
				current = e[1]
				output = G.node[current]['dialogue']
				print 'OUTPUT: %s' %output
				with open("clean.log","r+") as g:
					content = g.read()
					g.seek(0,0)
		    			g.write(output.rstrip('\r\n')+'\n'+content)
		    			g.close()
				if G.out_degree(current) == 0:
					current = root
	

