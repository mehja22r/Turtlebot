from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome('/home/caitlin/Downloads/chromedriver')
driver.get('http://www.speech.cs.cmu.edu/tools/lmtool-new.html')

driver.find_element_by_name('corpus').click()
driver.find_element_by_css_selector("input[type=\"file\"]").clear()
driver.find_element_by_css_selector("input[type=\"file\"]").send_keys("/opt/ros/indigo/share/pocketsphinx/demo/grammar.word")
driver.find_element_by_css_selector("input[type=\"submit\"]").click()

(driver.find_elements_by_partial_link_text('.dic'))[0].click()

text = driver.find_element_by_xpath("/html/body/pre").text;
driver.close()

dic = open("turtlebot_dic.dic", "w")
dic.write(text)
dic.close()
