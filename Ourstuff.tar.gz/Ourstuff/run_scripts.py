#!/bin/bash

import subprocess

subprocess.Popen(["python", "make_grammar.py"])
subprocess.Popen(["python", "test.py"])
subprocess.Popen(["python", "read_graph.py"])
#args = ('pocketsphinx_continuous', "-inmic", "yes", "-jsgf", "grammar.jsgf", "-dict", "turtlebot_dic.dic", "2>./unwanted-stuff.log", "|", "tee", "./words.log")
#cam2 = subprocess.Popen(['pocketsphinx_continuous', "-inmic", "yes", "-jsgf", "grammar.jsgf", "-dict", "turtlebot_dic.dic", "2>./unwanted-stuff.log", "|", "tee", "./words.log"], creationflags = subprocess.CREATE_NEW_CONSOLE)
subprocess.call(['gnome-terminal', '-x', 'bash', '-c', 'cd /opt/ros/indigo/share/pocketsphinx/demo/Ourstuff; pocketsphinx_continuous -inmic yes -jsgf grammar.jsgf -dict turtlebot_dic.dic 2>./unwanted-stuff.log | tee ./words.log'])

